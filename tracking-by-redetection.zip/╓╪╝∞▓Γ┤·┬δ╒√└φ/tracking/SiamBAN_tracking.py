import argparse, cv2, torch, json
import re

import numpy as np
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'

from os import makedirs
from os.path import realpath, dirname, join, isdir, exists

from tracking.snot.core.config_ban import cfg
from tracking.snot.models.siamban_model import ModelBuilderBAN
from tracking.snot.trackers.tracker_builder_ban import build_tracker_ban
from tracking.snot.utils.bbox import get_axis_aligned_bbox
from tracking.snot.utils.model_load import load_pretrain

from PyQt5.QtGui import *
from PyQt5.QtWidgets import QApplication

from skimage.io import imread, imshow
from skimage.transform import resize
from skimage.feature import hog
from skimage import data, exposure
import sys
sys.path.append('../detection')
import detection.detect
from tracking.kalman_filter import KalmanFilter

parser = argparse.ArgumentParser(description='PyTorch SiamRPN Test')
parser.add_argument('--dataset', dest='dataset', default='UAV20L', help='datasets')
parser.add_argument('--sequence', dest='sequence', default='', type=str, help='Specific sequence to track')
parser.add_argument('--config', default='../experiments/SiamBAN/config.yaml', type=str,
                    help='config file')
parser.add_argument('--snapshot', default='../experiments/SiamBAN/model.pth', type=str,
                    help='snapshot of models to eval')
#parser.add_argument('--dataset', dest='dataset', default='OTB100', help='datasets')
parser.add_argument('-v', '--visualization', dest='visualization', action='store_true',
                    help='whether visualize result')
parser.add_argument('-e', '--evaluate', dest='evaluation', action='store_true',
                    help='whether evaluate performance')
args = parser.parse_args()

LOG = "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'SimSun\'; font-weight:600;\">&lt;LOG&gt;&nbsp;&nbsp;</span>"
FORMAT_front = "<span style=\" font-family:\'SimSun\';\">"
FORMAT_front_color = "<span style=\" color:#fa5a00; font-family:\'SimSun\';\">"
FORMAT_end = "</span></p>\n"

OLRofPr = 0.0  # 追踪精度Pr计算尚未完成时的累加OLR
OLRofRe = 0.0  # 回归率Re计算尚未完成时的累加OLR
frameOfPr = 0  # 追踪精度Pr计算尚未完成时符合条件的累计帧数，论文中的Np
frameOfRe = 0  # 回归率Re计算尚未完成时符合条件的累计帧数，论文中的Ng

# load config
cfg.merge_from_file(args.config)

# create model
model = ModelBuilderBAN()

# load model
model = load_pretrain(model, args.snapshot).cuda().eval()

# build tracker
tracker = build_tracker_ban(model)

# 将坐标pos(cx, cy), sz(w, h)转换成矩形框的表示形式(x, y, w, h)
def cxy_wh_2_rect(pos, sz):
    return np.array([pos[0] - sz[0] / 2, pos[1] - sz[1] / 2, sz[0], sz[1]])  # 0-index


# 将矩形框的表示形式转换为坐标
def rect_2_cxy_wh(rect):
    return np.array([rect[0] + rect[2] / 2, rect[1] + rect[3] / 2]), np.array([rect[2], rect[3]])  # 0-index


def rect_2_cxywh(rect):
    return list([rect[0] + rect[2] / 2, rect[1] + rect[3] / 2, rect[2], rect[3]])  # 0-index

# 输入的img与img_tmp为图像数据
def hog_dot_API(img, img_tmp, label, label_tmp):
    # 加载灰度图像
    img1 = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img2 = cv2.cvtColor(img_tmp, cv2.COLOR_BGR2GRAY)
    # 坐标转化
    cx1, cy1, w1, h1 = label
    cx1 = round(cx1)
    cy1 = round(cy1)
    wh1 = round(w1/2)
    hh1 = round(h1/2)
    cx2, cy2, w2, h2 = label_tmp
    cx2 = round(cx2)
    cy2 = round(cy2)
    wh2 = round(w2/2)
    hh2 = round(h2/2)
    # 裁剪局部图像并进行大小调整
    part_img1 = resize(img1[(cy1 - hh1): (cy1 + hh1), (cx1 - wh1): (cx1 + wh1)], (128,128))
    part_img2 = resize(img2[(cy2 - hh2): (cy2 + hh2), (cx2 - wh2): (cx2 + wh2)], (128,128))
    # 计算两个局部图片的HOG特征
    fd1, hog1 = hog(part_img1, orientations=9, pixels_per_cell=(8,8), cells_per_block=(1,1), visualize=True)
    fd2, hog2 = hog(part_img2, orientations=9, pixels_per_cell=(8,8), cells_per_block=(1,1), visualize=True)
    ## 绘制HOG图像观察
    #hog_image_rescaled1 = exposure.rescale_intensity(hog1, out_range=(0, 10))
    #hog_image_rescaled2 = exposure.rescale_intensity(hog2, out_range=(0, 10))
    #cv2.imshow('img1', part_img1)
    #cv2.imshow('img2', part_img2)
    #cv2.waitKey(1)
    #cv2.imshow('hog1', hog_image_rescaled1)
    #cv2.imshow('hog2', hog_image_rescaled2)
    #cv2.waitKey(1)
    # 返回相似度
    return np.dot(fd1, fd2) / (np.linalg.norm(fd1) * np.linalg.norm(fd2))

# 输入的img与img_tmp为路径
def hog_dot(img, img_tmp, label, label_tmp):
    # 加载灰度图像
    img1 = cv2.imread(img, cv2.IMREAD_GRAYSCALE)
    img2 = cv2.imread(img_tmp, cv2.IMREAD_GRAYSCALE)
    # 坐标转化
    cx1, cy1, w1, h1 = label
    cx1 = round(cx1)
    cy1 = round(cy1)
    wh1 = round(w1/2)
    hh1 = round(h1/2)
    cx2, cy2, w2, h2 = label_tmp
    cx2 = round(cx2)
    cy2 = round(cy2)
    wh2 = round(w2/2)
    hh2 = round(h2/2)
    # 裁剪局部图像并进行大小调整
    part_img1 = resize(img1[(cy1 - hh1): (cy1 + hh1), (cx1 - wh1): (cx1 + wh1)], (128,128))
    part_img2 = resize(img2[(cy2 - hh2): (cy2 + hh2), (cx2 - wh2): (cx2 + wh2)], (128,128))
    # 计算两个局部图片的HOG特征
    fd1, hog1 = hog(part_img1, orientations=9, pixels_per_cell=(8,8), cells_per_block=(1,1), visualize=True)
    fd2, hog2 = hog(part_img2, orientations=9, pixels_per_cell=(8,8), cells_per_block=(1,1), visualize=True)
    # 绘制HOG图像观察
    hog_image_rescaled1 = exposure.rescale_intensity(hog1, out_range=(0, 10))
    hog_image_rescaled2 = exposure.rescale_intensity(hog2, out_range=(0, 10))
    #cv2.imshow('img1', part_img1)
    #cv2.imshow('img2', part_img2)
    #cv2.waitKey(1)
    #cv2.imshow('hog1', hog_image_rescaled1)
    #cv2.imshow('hog2', hog_image_rescaled2)
    #cv2.waitKey(1)
    # 返回相似度
    return np.dot(fd1, fd2) / (np.linalg.norm(fd1) * np.linalg.norm(fd2))

# net：          跟踪神经网络
# source_file：  视频文件位置
# output_path：  结果保存位置
# model_name：   目标检测的模型
# object_data：  选择的跟踪对象坐标
def track_video_API(net, source_file, output_path, model_name, object_data, window):
    # 全局变量
    toc = 0                 # toc 时间计数器
    regions = []            # regions 跟踪结果坐标数据 (左上角x, 左上角y, w, h)
    basic_img = []          # 基准帧数据
    first_img = []          # 初始帧数据
    target_pos = []         # 跟踪目标坐标
    target_sz = []          # 跟踪目标大小
    state_machine = 'init'  # 状态机标志
    pri = ''                # 上一个状态标志
    f = -1                  # 帧号
    ftag = True             # 不跳帧标志
    # 视频文件
    cap = cv2.VideoCapture(source_file)
    # 视频是否没到文件尾
    r = True
    # 遍历视频文件所有帧 (f:索引号 image_file:帧)
    while not window.ExitTag:
        # 获取一帧
        if ftag:
            r, image_file = cap.read()  # 注意：解析的图片是BGR
            if not r: # 取到文件结尾了
                window.pushButton_8.setEnabled(False)
                window.pushButton.setEnabled(True)
                window.pushButton_2.setEnabled(True)
                window.pushButton_3.setEnabled(True)
                window.pushButton_5.setEnabled(True)
                window.pushButton_7.setEnabled(True)
                window.ExitTag = False
                window.textBrowser.setHtml(
                    window.textBrowser.toHtml() + LOG + FORMAT_front + "Tracking is over!" + FORMAT_end)
                window.textBrowser.moveCursor(window.textBrowser.textCursor().End)
                window.textBrowser.setHtml(
                    window.textBrowser.toHtml() + LOG + FORMAT_front + "=========================================" + FORMAT_end)
                window.textBrowser.moveCursor(window.textBrowser.textCursor().End)
                break;
        else:
            ftag = True
        f = f + 1
        # 打印调试信息
        if pri != state_machine:
            print(str(f)+'  '+state_machine)
            if state_machine == 'redetect':
                window.textBrowser.setHtml(window.textBrowser.toHtml() + LOG + FORMAT_front_color + "Object missing. Redetecting..." + FORMAT_end)
                window.textBrowser.moveCursor(window.textBrowser.textCursor().End)
            pri=state_machine
        if f == 0:
            first_img = image_file
            basic_img = image_file
            # YOLO格式：(cx, cy, w, h)，转换为坐标pos(cx, cy), sz(w, h)
            target_pos = object_data[0:2]
            target_sz = object_data[2:4]
        tic = cv2.getTickCount()  # 处理前获取时间戳
        # init 初始化
        if state_machine == 'init':
            #print("---------init---------")

            cx, cy, w, h = get_axis_aligned_bbox(np.array(target_pos, target_sz))
            gt_bbox_ = [cx - (w - 1) / 2, cy - (h - 1) / 2, w, h]
            tracker.init(state, gt_bbox_)
            pred_bbox = gt_bbox_
            regions.append(pred_bbox)
            # 重检测完重新设置状态机为0
            state_machine = 'track'
            # state['bbox'] = pred_bbox
            # state['redetection'] = False
        # tracking 跟踪
        elif state_machine == 'track':
            #print("-------tracking-------")
            # 跟踪
            state = tracker.track(state)
            pred_bbox = state['bbox']
            regions.append(pred_bbox)
            # 判断是否需要重检测
            if state['redetection']:
                state_machine = 'redetect'

        elif  state_machine == 'redetect':  # redetection
            # 重检测（注意不会画框）
            # print("------retracking------")
            # 得到检测的目标坐标
            #print(os.getcwd())
            weights = os.path.join(os.getcwd(),'detection/weights',model_name+'.pt')
            yaml = os.path.join(os.getcwd(),'detection/data/',model_name+'.yaml')
            #label = detect.DetectAPI_inpath(source=im, view_img=False, save_txt=False, save_conf=False).run()
            label = detection.detect.DetectAPI_indata(source=image_file, weights=weights, data=yaml).run()
            #print(label)
            # 最大相似度 sim_max 和最大相似度的目标索引 i_index
            sim_max = 0
            i_index = 0
            # 遍历图片中存在的所有目标，即所有行
            for i, line in enumerate(label):
                # 与初始框计算相似度
                sim = hog_dot_API(image_file, first_img, line[1:5], object_data) # 当前图片数据，对比图片数据，当前框中心点坐标宽高，对比框中心点坐标宽高
                #sim = hog_dot_API(image_file, basic_img, line[1:5], target_pos+target_sz) # object_data可改为上一次初始化的头一帧
                #print('({:d}) target similarity: {:12f}'.format(i, sim))
                window.textBrowser.setHtml(
                    window.textBrowser.toHtml() + LOG + FORMAT_front + '= Target similarity:({:d}) {:12f}'.format(i, sim) + FORMAT_end)
                window.textBrowser.moveCursor(window.textBrowser.textCursor().End)
                if sim > sim_max:
                    i_index = i
                    sim_max = sim
            if sim_max > 0.55:  # TODO：修改相似度为输入参数
                # 重新运行跟踪代码
                state_machine = 'init'
                basic_img = image_file
                target_pos = label[i_index][1:3]
                target_sz = label[i_index][3:5]
                f = f - 1
                ftag = False
                #print('new target_pos: {:s} new target_sz: {:s}'.format(target_pos.__str__(), target_sz.__str__()))
                window.textBrowser.setHtml(
                    window.textBrowser.toHtml() + LOG + FORMAT_front_color + 'Object redetection successful!' + FORMAT_end)
                window.textBrowser.moveCursor(window.textBrowser.textCursor().End)
                window.textBrowser.setHtml(
                    window.textBrowser.toHtml() + LOG + FORMAT_front +
                    '= Similarity: ' + str(sim_max) + FORMAT_end)
                window.textBrowser.moveCursor(window.textBrowser.textCursor().End)
                window.textBrowser.setHtml(
                    window.textBrowser.toHtml() + LOG + FORMAT_front +
                    '= New target_pos: {:s} New target_sz: {:s}'.format(target_pos.__str__(), target_sz.__str__()) + FORMAT_end)
                window.textBrowser.moveCursor(window.textBrowser.textCursor().End)
            else:
                state = tracker.track(state)
                # 将坐标pos(cx, cy), sz(w, h)转换成矩形框的表示形式(x, y, w, h)
                pred_bbox = state['bbox']
                regions.append(pred_bbox)
                # regions.append([0, 0, 0, 0])
        toc += cv2.getTickCount() - tic  # 处理完记录花费的总时间

        # 在窗口中绘制原始图像
        h, w, ch = image_file.shape
        bytesPerLine = ch * w
        qImg = QImage(image_file.data, w, h, bytesPerLine, QImage.Format_RGB888)
        qImg = qImg.rgbSwapped()
        pixmap = QPixmap.fromImage(qImg)
        pixmap = pixmap.scaled(window.label_7.width(), window.label_7.height(), 1, 0)
        #window.label_7.setScaledContents(True)
        window.label_7.setPixmap(pixmap)

        # 绘制预测框
        if len(location) == 8:      # 可旋转的矩形框模式
            cv2.polylines(image_file, [location.reshape((-1, 1, 2))], True, (0, 255, 255), 3)
        else:                       # 不可旋转的矩形框模式
            location = [int(l) for l in location]
            cv2.rectangle(image_file, (location[0], location[1]),
                          (location[0] + location[2], location[1] + location[3]), (0, 255, 255), 3)
        # 在窗口中绘制跟踪图像
        qImg = QImage(image_file.data, w, h, bytesPerLine, QImage.Format_RGB888)
        qImg = qImg.rgbSwapped()
        pixmap = QPixmap.fromImage(qImg)
        pixmap = pixmap.scaled(window.label_8.width(), window.label_8.height(), 1, 0)
        #window.label_8.setScaledContents(True)
        window.label_8.setPixmap(pixmap)
        window.label_10.setText("(" + str(location[0]) + ", " + str(location[1]) + ")") #location
        window.label_12.setText("w: " + str(location[2]) + ", h: " + str(location[3])) #size

        QApplication.processEvents()

    toc /= cv2.getTickFrequency()  # 计算总平均处理时间
    cap.release()
    # 结果保存
    # TODO：保存跟踪结果 regions 和 视频 在 output_path


    return regions # 返回所有的坐标数据


def track_video(model, video, dataset_name):
    # 全局变量
    toc = 0  # toc 时间计数器
    regions = []  # regions 跟踪结果坐标数据 (左上角x, 左上角y, w, h)
    score = []
    basic_img = []  # 基准帧数据
    first_img = []  # 初始帧数据
    target_pos = []  # 跟踪目标坐标
    target_sz = []  # 跟踪目标大小
    state_machine = 'init'  # 状态机标志
    pri = ''  # 上一个状态标志
    f = -1  # 帧号
    kf = KalmanFilter()
    kf_initial_state = None  # 初始状态设置为None，稍后根据第一次成功跟踪结果进行初始化

    image_files, gt = video['image_files'], video['gt']
    # image_files, gt = video['img_names'], video['gt']
    # 遍历文件所有帧 (f:索引号 image_file:帧)
    while f < len(image_files) - 1:
        f = f + 1
        # 打印调试信息
        if pri != state_machine:
            print(str(f) + '  ' + state_machine)
            if state_machine == 'redetect':
                print(str(f)+'  '+state_machine)
            pri = state_machine
        image_file = image_files[f]
        im = cv2.imread(image_file)  # 获取一帧
        tic = cv2.getTickCount()  # 处理前获取时间戳
        if f == 0:
            first_img = image_file
            basic_img = image_file
            # OTB格式：(x, y, w, h)，左上角点的位置，宽，高
            # 将矩形框的表示形式(x, y, w, h)转换为坐标pos(cx, cy), sz(w, h)
            target_pos, target_sz = rect_2_cxy_wh(gt[0])
        # init 初始化
        if state_machine == 'init':
            # print("---------init---------")
            # 初始化 tracker
            location = cxy_wh_2_rect(target_pos, target_sz)

            state = tracker.init(im, location)
            # 保存矩形框信息
            regions.append(location)
            score.append(1)
            # 重检测完重新设置状态机为0
            state_machine = 'track'
        # tracking 跟踪
        elif state_machine == 'track':
            # print("-------tracking-------")
            # 跟踪
            state = tracker.track(im)
            # 判断是否需要重检测
            if state['redetection']:
                state_machine = 'redetect'
            # 将坐标pos(cx, cy), sz(w, h)转换成矩形框的表示形式(x, y, w, h)
            location = state['bbox']
            regions.append(location)
            # measurement = np.array([state['target_pos'], state['target_sz']]).reshape(-1)  # 假设速度为0

        elif state_machine == 'redetect':  # redetection
            # 重检测（注意不会画框）
            # print("------retracking------")
            # 得到检测的目标坐标
            # print(os.getcwd())
            # weights = os.path.join(os.getcwd(), '../detection/weights/UAV123.pt')
            weights = os.path.join(os.getcwd(), '../detection/weights', dataset_name + '.pt')
            yaml = os.path.join(os.getcwd(), '../detection/data/', dataset_name + '.yaml')
            # label = detect.DetectAPI_inpath(source=im, view_img=False, save_txt=False, save_conf=False).run()
            label = detection.detect.DetectAPI_indata(source=im, weights=weights, data=yaml).run()
            # print(label)
            # 最大相似度 sim_max 和最大相似度的目标索引 i_index
            sim_max = 0
            i_index = 0
            # 遍历图片中存在的所有目标，即所有行
            for i, line in enumerate(label):
                # 与初始框计算相似度
                # TODO：object_data改为上一次初始化的头一帧
                # 当前图片数据，对比图片数据，当前框中心点坐标宽高，对比框中心点坐标宽高
                sim = hog_dot(image_file, first_img, line[1:5], rect_2_cxywh(gt[0]))
                #sim = hog_dot(image_file, basic_img, line[1:5], target_pos+target_sz)
                #print(sim)
                if sim > sim_max:
                    i_index = i
                    sim_max = sim
            if sim_max > 0.55:  # TODO：修改相似度为输入参数
                # 重新运行跟踪代码
                state_machine = 'init'
                basic_img = image_file
                target_pos = label[i_index][1:3]
                target_sz = label[i_index][3:5]
                f = f - 1
                measurement = np.array([*target_pos, *target_sz])  # 假设速度为0
                kf_initial_state = kf.initiate(measurement)
                # print('new target_pos: {:s} new target_sz: {:s}'.format(target_pos.__str__(), target_sz.__str__()))
            else:
                state = tracker.track(im)
                # 将坐标pos(cx, cy), sz(w, h)转换成矩形框的表示形式(x, y, w, h)
                location = state['bbox']
                # 保存矩形框信息
                regions.append(location)
                # score.append(state['score'])

        toc += cv2.getTickCount() - tic  # 处理完记录花费的总时间

        if args.visualization and f >= 0:
            if f == 0: cv2.destroyAllWindows()
            # 绘制正确框
            if len(gt[f]) == 8:  # 可旋转的矩形框模式
                cv2.polylines(im, [np.array(gt[f], np.int).reshape((-1, 1, 2))], True, (0, 255, 0), 3)
            else:  # 不可旋转的矩形框模式
                cv2.rectangle(im, (gt[f, 0], gt[f, 1]), (gt[f, 0] + gt[f, 2], gt[f, 1] + gt[f, 3]), (0, 255, 0), 3)
            # 绘制预测框
            if len(location) == 8:  # 可旋转的矩形框模式
                cv2.polylines(im, [location.reshape((-1, 1, 2))], True, (0, 255, 255), 3)
            else:  # 不可旋转的矩形框模式
                location = [int(l) for l in location]
                cv2.rectangle(im, (location[0], location[1]),
                              (location[0] + location[2], location[1] + location[3]), (0, 255, 255), 3)
            # 输出帧号信息
            cv2.putText(im, str(f), (40, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
            # 在窗口显示图像
            cv2.imshow(video['name'], im)
            cv2.waitKey(1)

    toc /= cv2.getTickFrequency()  # 计算总平均处理时间

    # save result
    if dataset_name == 'OTB2015':
        video_path = join('val', dataset_name, 'SiamRPN-yolo_OTB2015')
    elif dataset_name == 'UAV20L':
        video_path = join('val', dataset_name, 'SiamRPN-yolo_UAV20L')
    if not isdir(video_path): makedirs(video_path)
    result_path = join(video_path, '{:s}_reg.txt'.format(video['name']))
    result_path2 = join(video_path, '{:s}_sco.txt'.format(video['name']))
    with open(result_path, "w") as fin:
        for x in regions:
            fin.write(','.join([str(i) for i in x]) + '\n')
    with open(result_path2, "w") as fin:
        for x in score:
            fin.write(str(x) + '\n')

    print('({:d}) Video: {:12s} Time: {:02.1f}s Speed: {:3.1f}fps'.format(
        v_id, video['name'], toc, f / toc))
    return f / toc


def load_dataset(dataset, specific_group='group2'):
    if dataset == 'OTB100':
        base_path = join(realpath(dirname(__file__)), 'data', dataset)  # 当前路径下/data/$dataset_name文件夹
        # ./code/data/OTB2015
        if not exists(base_path):
            print("Please download OTB dataset into `data` folder!")
            exit()
        json_path = join(realpath(dirname(__file__)), 'data', dataset + '.json')  # 当前路径下/data/$dataset_name.json文件
        # ./code/data/OTB2015.json
    elif dataset == 'UAV20L':
        base_path = join(os.path.abspath(os.path.join(os.getcwd(), os.pardir)), 'mydata', 'UAV20L') # 当前路径下上一级的/mydata/UAV123
        # ../mydata/UAV123
        if not exists(base_path):
            print("Please download OTB dataset into `data` folder!")
            exit()
        json_path = join(base_path, dataset + '.json')  # 当前路径下上一级的/mydata/UAV123/$dataset_name.json文件
        #../mydata/UAV123/UAV20L.json
    info = json.load(open(json_path, 'r'))

    for v in info.keys():
        path_name = info[v]['name']  # 文件夹名字

        # path_name = info[v]['video_dir']  # 文件夹名字
        if dataset == 'OTB100':
            info[v]['img_names'] = [join(base_path, path_name, 'img', im_f) for im_f in
                                    info[v]['img_names']]  # 各个图片名字
            info[v]['gt'] = np.array(info[v]['gt_rect']) - [1, 1, 0, 0]  # 第1帧起的所有真实框 # our tracker is 0-index
        else:
            info[v]['image_files'] = [join(base_path, 'img', im_f) for im_f in
                                      info[v]['image_files']]  # 各个图片名字
            info[v]['gt'] = np.array(info[v]['gt_rect'])
        info[v]['name'] = v
    return info


# =============================================================================================
def initOLR():
    global OLRofPr, frameOfPr, OLRofRe, frameOfRe
    OLRofPr = 0.0  # 追踪精度Pr计算尚未完成时的累加OLR
    OLRofRe = 0.0  # 回归率Re计算尚未完成时的累加OLR
    frameOfPr = 0  # 追踪精度Pr计算尚未完成时符合条件的累计帧数，论文中的Np
    frameOfRe = 0  # 回归率Re计算尚未完成时符合条件的累计帧数，论文中的Ng

# 计算给定区域和跟踪结果的区域重叠率OverlapRate
def countOLR(trackXmin, trackYmin, trackXmax, trackYmax, giveXmin, giveYmin, giveXmax, giveYmax):
    areaTrack = 0.0
    areaGive = 0.0
    areaCommon = 0.0
    x = [trackXmin, trackXmax, giveXmin, giveXmax]
    y = [trackYmin, trackYmax, giveYmin, giveYmax]
    # 排除无交集情况
    if (trackXmax <= giveXmin or giveXmax <= trackXmin):
        return 0.0
    if (trackYmax <= giveYmin or giveYmax <= trackYmin):
        return 0.0
    x.sort()
    y.sort()
    # 计算两个区域各自面积
    #print(str(trackXmin) + str(trackYmin) + str(trackXmax) + str(trackYmax) + str(giveXmin) + str(giveYmin) + str(giveXmax) + str(giveYmax))
    areaTrack = float((trackXmax - trackXmin) * (trackYmax - trackYmin))
    areaGive = float((giveXmax - giveXmin) * (giveYmax - giveYmin))
    areaCommon = float((x[2] - x[1]) * (y[2] - y[1]))
    OLR = areaCommon / (areaTrack + areaGive - areaCommon)
    return float(OLR)

# 累加计算Pr，注意仅应在tracker认为目标存在且给出Roi的帧调用(目标此时可能存在)
def calcPr(OLR):
    global OLRofPr, frameOfPr
    OLRofPr = OLR + OLRofPr
    frameOfPr = frameOfPr + 1
    return True

# 累加计算Re，注意仅应在序列给定的标注中目标存在且给出Roi的帧调用(目标此时肯定存在)
def calcRe(OLR):
    global OLRofRe, frameOfRe
    OLRofRe = OLR + OLRofRe
    frameOfRe = frameOfRe + 1
    return True

# 获取计算完毕的Pr
def getPr():
    global OLRofPr, frameOfPr
    return float(OLRofPr / frameOfPr)

# 获取计算完毕的Re
def getRe():
    global OLRofRe, frameOfRe
    return float(OLRofRe / frameOfRe)

# 获取计算完毕的F-score
def getFscore(Pr, Re):
    return float(2 * Pr * Re / (Pr + Re))



def main():
    global OLRofPr, frameOfPr, OLRofRe, frameOfRe
    global args, v_id
    # 解析参数
    args = parser.parse_args()

    # load config
    cfg.merge_from_file(args.config)

    # create model
    model = ModelBuilderBAN()

    # load model
    model = load_pretrain(model, args.snapshot).cuda().eval()

    # build tracker
    tracker = build_tracker_ban(model)
    dataset = load_dataset(args.dataset)
    # 筛选指定的序列
    if args.sequence:
        sequence_name = args.sequence
        if sequence_name in dataset:
            selected_sequence = {sequence_name: dataset[sequence_name]}
        else:
            print(f"Sequence {sequence_name} not found in dataset.")
            exit()
    else:
        selected_sequence = dataset  # 如果没有指定序列，则使用整个数据集

    fps_list = []
    for v_id, video in enumerate(selected_sequence.keys()):
        fps_list.append(track_video(model, selected_sequence[video], args.dataset))

    # evaluate performance
    if args.evaluation:
        Pr = []
        Re = []
        F = []
        name = []
        if args.dataset == 'OTB2015':
            video_path = join('val', args.dataset, 'SiamRPN-yolo_OTB2015')
        elif args.dataset == 'UAV20L':
            video_path = join('val', args.dataset, 'SiamRPN-yolo_UAV20L')
        evalu = []
        for v, filename in enumerate(os.listdir(video_path)):
            if '_' in filename:
                if re.split(r'_', filename)[1] == 'reg.txt':
                    initOLR()
                    classname = re.split(r'_', filename)[0]
                    evalu = []
                    with open(os.path.join(video_path, filename), "r") as result:
                        for i, line in enumerate(result):
                            track_location = re.split(r',', line)
                            OLR = countOLR(float(track_location[0]), float(track_location[1]),
                                           float(track_location[0]) + float(track_location[2]),
                                           float(track_location[1]) + float(track_location[3]),
                                           dataset[classname]['gt'][i][0],  dataset[classname]['gt'][i][1],
                                           dataset[classname]['gt'][i][0] + dataset[classname]['gt'][i][2],
                                           dataset[classname]['gt'][i][1] + dataset[classname]['gt'][i][3])
                            if line == "0,0,0,0\n" or dataset[classname]['gt'][i].tolist() == [0, 0, 0, 0]:
                                evalu.append(0)
                            else:
                                evalu.append(OLR)
                            if line != "0,0,0,0\n":
                                calcPr(OLR)
                            if dataset[classname]['gt'][i].tolist() != [0, 0, 0, 0]:
                                calcRe(OLR)
                    Pr.append(getPr())
                    Re.append(getRe())
                    F.append(getFscore(getPr(), getRe()))
                    name.append(re.split(r'_', filename)[0])
                    print("-----")
                    print(getPr())
                    print(getRe())
                    print(getFscore(getPr(), getRe()))
                    print(re.split(r'_', filename)[0])

                evalu_path = join(video_path, '{:s}_olr.txt'.format(re.split(r'_', filename)[0]))
                with open(evalu_path, "w") as fin:
                    for x in evalu:
                        fin.write(str(x) + '\n')
        evalu_path = join(video_path, 'PRF.txt')
        ff = open(evalu_path, 'w')
        ff.close()
        with open(evalu_path, "a") as fin:
            i = 0
            while i < len(name):
                fin.write(str(name[i])+','+str(Pr[i])+','+str(Re[i])+','+str(F[i])+'\n')
                i = i + 1

    print('Mean Running Speed {:.1f}fps'.format(np.mean(np.array(fps_list))))


if __name__ == '__main__':
    main()