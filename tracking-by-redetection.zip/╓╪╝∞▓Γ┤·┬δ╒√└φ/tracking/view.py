import cv2
import os
import numpy as np

'''
def visualize_tracking(frames_path, results_path):
    """
    可视化跟踪结果
    :param frames_path: 图片帧的文件夹路径
    :param results_path: 跟踪结果文件的路径
    """
    # 读取跟踪结果
    with open(results_path, 'r') as f:
        lines = f.readlines()
    boxes = [list(map(float, line.split(','))) for line in lines]

    # 获取所有帧的文件名并排序
    frame_files = sorted([f for f in os.listdir(frames_path) if f.endswith(('.jpg', '.png'))])

    for idx, frame_file in enumerate(frame_files):
        frame_path = os.path.join(frames_path, frame_file)
        frame = cv2.imread(frame_path)
        if frame is None:
            continue  # 跳过无法读取的帧

        # 绘制边界框
        if idx < len(boxes):
            box = boxes[idx]
            pt1 = (int(box[0]), int(box[1]))
            pt2 = (int(box[0] + box[2]), int(box[1] + box[3]))
            cv2.rectangle(frame, pt1, pt2, (0, 255, 0), 2)

        cv2.imshow('Tracking Visualization', frame)
        if cv2.waitKey(100) & 0xFF == ord('q'):
            break  # 按q退出

    cv2.destroyAllWindows()
'''

def visualize_tracking(frames_path, results_path):
    """
    可视化跟踪结果，并提供保存当前显示帧的功能
    :param frames_path: 图片帧的文件夹路径
    :param results_path: 跟踪结果文件的路径
    """
    # 读取跟踪结果
    with open(results_path, 'r') as f:
        lines = f.readlines()
    boxes = [list(map(float, line.split(','))) for line in lines]

    # 获取所有帧的文件名并排序
    frame_files = sorted([f for f in os.listdir(frames_path) if f.endswith(('.jpg', '.png'))])

    # 设置保存图片的文件夹
    save_folder = os.path.join(frames_path, "saved_frames")
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)

    for idx, frame_file in enumerate(frame_files):
        frame_path = os.path.join(frames_path, frame_file)
        frame = cv2.imread(frame_path)
        if frame is None:
            continue  # 跳过无法读取的帧

        # 绘制边界框
        if idx < len(boxes):
            box = boxes[idx]
            pt1 = (int(box[0]), int(box[1]))
            pt2 = (int(box[0] + box[2]), int(box[1] + box[3]))
            cv2.rectangle(frame, pt1, pt2, (0, 255, 0), 2)

        cv2.imshow('Tracking Visualization', frame)
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q'):
            break  # 按q退出
        elif key == ord('s'):  # 按s保存当前帧
            save_path = os.path.join(save_folder, f"saved_frame_{idx}.jpg")
            cv2.imwrite(save_path, frame)
            print(f"Frame {idx} saved at {save_path}.")

    cv2.destroyAllWindows()
# 示例用法
dataset_folder = 'F:\\Dataset_UAV123\\UAV123\data_seq\\UAV20L'  # 数据集视频的文件夹路径
results_folder = 'E:\\DaSiamRPN-yolo\\tracking\\val\\UAV20L\\SiamRPN-yolo_UAV20L'  # 结果文件夹路径
def main():
    for sequence in os.listdir(dataset_folder):
        sequence_path = os.path.join(dataset_folder, sequence)
        if os.path.isdir(sequence_path):
            result_file = f'{sequence}_reg.txt'
            results_path = os.path.join(results_folder, result_file)
            if os.path.exists(results_path) and sequence == "group2":
                print(f'Visualizing {sequence}...')
                visualize_tracking(sequence_path, results_path)
            else:
                print(f'Results file for {sequence} not found.')


if __name__ == '__main__':
    main()
