#!/usr/bin/python
#-*- coding:utf-8 -*-
# --------------------------------------------------------
# DaSiamRPN
# Licensed under The MIT License
# Written by Qiang Wang (wangqiang2015 at ia.ac.cn)
# --------------------------------------------------------
#!/usr/bin/python

import tracking.vot
from tracking.vot import Rectangle
import sys
import cv2  # imread
import torch
import numpy as np
from os.path import realpath, dirname, join

from net import SiamRPNBIG
from run_SiamRPN import SiamRPN_init, SiamRPN_track
from utils_track import get_axis_aligned_bbox, cxy_wh_2_rect

# load net 创建网络并加载模型
net = SiamRPNBIG() #初始化
net.load_state_dict(torch.load(join(realpath(dirname(__file__)), 'SiamRPNBIG.model'),map_location='cpu')) #用内部定义的dict保存模型参数，不带模型结构
#net.eval().cuda() #不启用 BatchNormalization 和 Dropout
net.eval()
"""
    model.eval()  设置为测试模式
    自动把 BN 和 DropOut 固定住，不会取平均，而是用训练好的值。
    不然的话，一旦test的batch_size过小，很容易就会因BN层导致模型performance损失较大。
    
    model.train()  设置为训练模式
    启用 BatchNormalization 和 Dropout。
    此时 dropout 和 batch normalization 的操作在训练中起到防止网络过拟合的问题。
    
    cuda()
    将所有模型参数和缓冲区移动到GPU
"""

# warm up 预热 运行模板分支(net.temple)和检测分支(net)10次
for i in range(10):
    #net.temple(torch.autograd.Variable(torch.FloatTensor(1, 3, 127, 127)).cuda()) #3*127*127的张量
    #net(torch.autograd.Variable(torch.FloatTensor(1, 3, 255, 255)).cuda()) #3*255*255的张量
    net.temple(torch.autograd.Variable(torch.FloatTensor(1, 3, 127, 127))) #3*127*127的张量
    net(torch.autograd.Variable(torch.FloatTensor(1, 3, 255, 255))) #3*255*255的张量

"""
    如果有参数，使用 torch.nn.Module 而非 torch.nn.Module.forward ，因为前者负责运行已注册的钩子，而后者默默地忽略它们。

    刚开始训练时,模型的权重(weights)是随机初始化的，此时若选择一个较大的学习率,可能带来模型的不稳定(振荡)，
    选择Warmup预热学习率的方式，可以使得开始训练的几个epoches或者一些steps内学习率较小,
    在预热的小学习率下，模型可以慢慢趋于稳定,等模型相对稳定后再选择预先设置的学习率进行训练,
    使得模型收敛速度变得更快，模型效果更佳。
"""
# start to track 开始跟踪
handle = vot.VOT("polygon") #创建一个 VOT 多边形对象
Polygon = handle.region() #接收初始化区域和第一个图像的路径。返回值为初始化区域。
cx, cy, w, h = get_axis_aligned_bbox(Polygon) #将坐标数据转换成 RPN 的格式

image_file = handle.frame() #获取帧（图像路径）
if not image_file:
    sys.exit(0)

# 读取图像并初始化跟踪器
target_pos, target_sz = np.array([cx, cy]), np.array([w, h]) # 目标位置和大小
im = cv2.imread(image_file)  # HxWxC
state = SiamRPN_init(im, target_pos, target_sz, net)  # init tracker
while True: #跟踪循环
    image_file = handle.frame() #获取帧（图像路径）
    if not image_file:
        break
    im = cv2.imread(image_file)  # HxWxC
    state = SiamRPN_track(state, im)  # track 运行检测分支并更新状态变量
    res = cxy_wh_2_rect(state['target_pos'], state['target_sz']) #将坐标转换成矩形框的表示形式

    handle.report(Rectangle(res[0], res[1], res[2], res[3])) #将跟踪结果报告给客户端

    """
    subwindow = get_subwindow_tracking(im, target_pos, p.instance_size, round(s_x), avg_chans)
    get_subwindow_tracking 获取跟踪目标的图像窗口，对目标框进行调整，若目标框在图像之外，则扩充图像，并修改目标框的坐标
    im：模板图像
    target_pos：中心点位置
    p.instance_size：模型要求的输入尺寸
    round(s_x)：拓展后的目标尺寸
    avg_chans：图像的平均值

    # TODO:裁剪识别到的各个目标图片
    # img1 = x_crop.data.squeeze(0)
    # print(type(img1))
    cv2.imshow('subimg', get_subwindow_tracking(im, target_pos, p.instance_size, round(s_x), avg_chans,
                                                out_mode='im_patch'))  # 在窗口中显示图像（窗口名称，图像）
    cv2.waitKey(1)  # 控制imshow的持续时间
    if redetection == True:
        state['redetection'] = True
        return state
    else:
        state['redetection'] = False

    crop_box = [target_pos[0] - round(s_x) / 2, target_pos[1] - round(s_x) / 2, round(s_x), round(s_x)]
    # 复制图片
    im_debug = im.copy()
    # 产生crop_box
    crop_box_int = np.int0(crop_box)
    # 将其绘制在图片上
    cv2.rectangle(im_debug, (crop_box_int[0], crop_box_int[1]),
                  (crop_box_int[0] + crop_box_int[2], crop_box_int[1] + crop_box_int[3]), (255, 0, 0), 2)
    # 图片展示
    cv2.imshow('search area', im_debug)
    cv2.waitKey(1)
    """
    # hog_sim()

